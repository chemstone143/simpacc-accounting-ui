export const Home = () => {
  return (
    <>
      <div className="text-center py-10">
        <span className="text-3xl">Welcome to Billing Module</span>
      </div>
    </>
  );
};
