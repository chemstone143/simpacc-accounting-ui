export const api = {
  BASE_URL: 'https://zirkels-redfalcon-app.dscodelab.com', // window.location.origin,
  CONTACTS_ENDPOINT: '/api/contacts',
};
