export const routes = {
  HOME: '/',
  CONTACTS: '/contacts',
};
